#ifndef STRMODERATOR_H
#define STRMODERATOR_H

#include "sScaler.h"

#include "sReader.h"

class sModerator{
public:
  sModerator(string fname) : r(fname){}
  ~sModerator() {}
  // inline void read(const string& fname) {sReader tmp(fname); r(tmp);}
  inline void scale() { while(r.hasNext()) s.add(r.next()); }
  inline void result() {s.output(); }
private:
  sReader r;
  sScaler s;
};

#endif
