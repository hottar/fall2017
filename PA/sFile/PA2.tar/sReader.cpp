#include "sReader.h"

bool sReader::hasNext(){
  ifstream::pos_type tmpLoc = file.tellg();
  bool retbool(true);
  string tmp;
  file >> tmp;
  if(file.eof()) retbool = false;
  else if(file.fail()) throw string("File contains value of non-string!");
  file.seekg(tmpLoc);
  return retbool;
}

string sReader::next() {
  string tmp;
  file >> tmp;
  return tmp;
}
